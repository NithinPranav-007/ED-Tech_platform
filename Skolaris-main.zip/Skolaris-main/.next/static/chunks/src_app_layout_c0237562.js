(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_@firebase_auth_dist_esm_c6ecf2de._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm_bf7383cb.js",
  "static/chunks/node_modules_67ec3010._.js",
  "static/chunks/src_64646211._.js"
],
    source: "dynamic"
});
