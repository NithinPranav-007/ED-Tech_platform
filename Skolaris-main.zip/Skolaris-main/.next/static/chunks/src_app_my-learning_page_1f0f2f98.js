(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b0ad4886._.js",
  "static/chunks/node_modules_next_6bab6250._.js"
],
    source: "dynamic"
});
