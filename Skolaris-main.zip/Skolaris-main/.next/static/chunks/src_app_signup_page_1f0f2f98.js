(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_6bab6250._.js",
  "static/chunks/src_app_signup_page_3122123a.js"
],
    source: "dynamic"
});
