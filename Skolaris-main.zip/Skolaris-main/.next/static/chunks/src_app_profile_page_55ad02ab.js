(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_c0301f25._.js",
  "static/chunks/src_ff5faf02._.js"
],
    source: "dynamic"
});
