"use client";
import Link from 'next/link';
import { useAuth } from '../../contexts/AuthContext';

const Hero = () => {
  const { currentUser } = useAuth();

  return (
    <section className="bg-white text-black py-20">
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          {currentUser ? `Welcome back, ${currentUser.email?.split('@')[0] || 'Learner'}!` : 'Welcome to Skolaris'}
        </h1>
        <p className="text-lg md:text-2xl mb-8">
          {currentUser ? 'Continue your learning journey today.' : 'Collaborate, Innovate, and Grow Together.'}
        </p>
        {!currentUser ? (
          <div className="flex justify-center space-x-4">
            <Link
              href="/signup"
              className="bg-black hover:bg-white hover:text-black hover:border border-black text-white py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              Get Started
            </Link>
            <Link
              href="/login"
              className="bg-transparent border border-black hover:bg-black hover:text-white text-black py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              Login
            </Link>
          </div>
        ) : (
          <div className="flex justify-center space-x-4">
            <Link
              href="/my-learning"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Continue Learning
            </Link>
            <Link
              href="/courses"
              className="bg-transparent border-2 border-blue-600 hover:bg-blue-600 hover:text-white text-blue-600 py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
            >
              Browse Courses
            </Link>
          </div>
        )}
      </div>
    </section>
  );
};

export default Hero;
