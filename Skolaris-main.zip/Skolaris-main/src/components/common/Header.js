"use client";
import Link from 'next/link';
import { useState } from 'react';
import Image from 'next/image';
import { useAuth } from '../../contexts/AuthContext';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { currentUser, logout } = useAuth();

  return (
    <header className="bg-white text-black shadow-md">
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center py-10 border-b border-black">
        

        <Link href="/" className="text-xl font-bold flex items-center">
          Skolaris
        </Link>

        <nav className="hidden md:flex items-center space-x-10 bg-black rounded-[30px] px-20 py-6">
          <Link href="/" className="font-medium text-white hover:text-blue-400 transition">
            Home
          </Link>
          <Link href="/courses" className="font-medium text-white hover:text-blue-400 transition">
            Courses
          </Link>
          <Link href="/my-learning" className="font-medium text-white hover:text-blue-400 transition">
            My Learning
          </Link>
        </nav>

        <div className="flex items-center space-x-4">
          {currentUser ? (
            <>
              {/* User Welcome */}
              <div className="hidden md:block text-sm text-gray-600">
                Welcome, <span className="font-semibold text-gray-800">{currentUser.email?.split('@')[0] || 'Learner'}</span>
              </div>
              
              {/* Points Display */}
              <div className="flex items-center bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full px-4 py-2 shadow-lg border border-yellow-300 transform hover:scale-105 transition-all duration-300">
                <svg className="w-5 h-5 text-white mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                <span className="font-bold text-white text-sm">50</span>
              </div>
              
              <Link href="/profile" className="ml-4 group relative">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 overflow-hidden border-2 border-white shadow-lg flex items-center justify-center transition-all duration-300 transform hover:scale-110 hover:shadow-xl">
                  <div className="relative w-full h-full flex items-center justify-center">
                    {currentUser.photoURL ? (
                      <Image
                        src={currentUser.photoURL}
                        alt="Profile"
                        fill
                        className="object-cover"
                        onError={(e) => {
                          // Hide the image and show initials if it fails to load
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'flex';
                        }}
                      />
                    ) : null}
                    <div 
                      className={`text-white font-bold text-lg ${currentUser.photoURL ? 'hidden' : 'flex'} items-center justify-center`}
                    >
                      {currentUser.email?.charAt(0).toUpperCase() || 'U'}
                    </div>
                  </div>
                </div>
                <div className="absolute opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded py-1 px-2 -bottom-8 left-1/2 transform -translate-x-1/2 transition-opacity duration-300 whitespace-nowrap">
                  Profile
                </div>
              </Link>
              
              <button
                onClick={logout}
                className="ml-2 px-3 py-1 text-sm bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all duration-300 transform hover:scale-105"
              >
                Logout
              </button>
            </>
          ) : (
            <div className="flex items-center space-x-3">
              <Link href="/login" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-300">
                Login
              </Link>
              <Link href="/signup" className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg text-sm font-medium hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg">
                Sign Up
              </Link>
            </div>
          )}

          <button
            className="ml-4 md:hidden focus:outline-none"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <svg
              className="w-6 h-6 text-black"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>


      {isMenuOpen && (
        <div className="md:hidden bg-gray-100 py-4 px-6">
          <div className="flex flex-col space-y-4">
            <Link 
              href="/" 
              className="font-medium text-black text-center border-b border-black hover:text-blue-500"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              href="/courses" 
              className="font-medium text-black text-center border-b border-black hover:text-blue-500"
              onClick={() => setIsMenuOpen(false)}
            >
              All Courses
            </Link>
            <Link 
              href="/my-learning" 
              className="font-medium text-black text-center border-b border-black hover:text-blue-500"
              onClick={() => setIsMenuOpen(false)}
            >
              My Learning
            </Link>
            {currentUser ? (
              <>
                <Link 
                  href="/profile" 
                  className="font-medium text-black text-center border-b border-black hover:text-blue-500"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Profile
                </Link>
                <button 
                  onClick={() => {
                    logout();
                    setIsMenuOpen(false);
                  }}
                  className="font-medium text-black text-center border-b border-black hover:text-blue-500"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link 
                  href="/login" 
                  className="font-medium text-black text-center border-b border-black hover:text-blue-500"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Login
                </Link>
                <Link 
                  href="/signup" 
                  className="font-medium text-black text-center border-b border-black hover:text-blue-500"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

