import React from 'react';
import Hero from '../components/home/Hero.js';
import ContinueLearning from '../components/home/ContinueLearning.js';
import BrowseCategories from '../components/home/BrowseCategories.js';
import FeaturedCourses from '../components/home/FeaturedCourses.js';
import Feature from '../components/home/Feature.js';
import Header from '../components/common/Header.js';
import Footer from '../components/common/Footer.js';



export default function Home() {
  return (
    <>
    <Header/>
    <main>
      <Hero />
      <ContinueLearning />
      <BrowseCategories />
      <FeaturedCourses />
      <Feature />
    </main>
    <Footer/>
    </>
  );
}
