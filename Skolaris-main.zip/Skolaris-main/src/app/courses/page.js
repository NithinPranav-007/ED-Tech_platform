'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import Header from '../../components/common/Header';
import Footer from '../../components/common/Footer';

const CoursesPage = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const searchParams = useSearchParams();

  const categories = ['All', 'Design', 'Development', 'Marketing', 'Business', 'Photography', 'Music'];

  useEffect(() => {
    // Get category from URL if present
    const categoryFromUrl = searchParams.get('category');
    if (categoryFromUrl) {
      setActiveCategory(categoryFromUrl);
    }

    setTimeout(() => {
      setCourses([
        // Design Courses
        {
          id: 1,
          image: "/images/advanced-ui-ux.avif",
          title: "Advanced UI/UX Design Principles",
          category: "Design",
          description: "Master advanced user interface and experience design.",
          instructor: "Emma Wilson",
          rating: 4.9,
          students: 3245,
          price: 1089.99,
          originalPrice: 1129.99,
        },
        {
          id: 2,
          image: "/images/GRAPHIC-DESIGN.jpg",
          title: "Graphic Design Fundamentals",
          category: "Design",
          description: "Create stunning visuals and graphics.",
          instructor: "Sophia Martinez",
          rating: 4.7,
          students: 2560,
          price: 3274.99,
          originalPrice: 3709.99,
        },
        {
          id: 3,
          image: "/images/ui-ux.jpg",
          title: "UI/UX Fundamentals",
          category: "Design",
          description: "Learn the basics of UI and UX design.",
          instructor: "Chris White",
          rating: 4.6,
          students: 1890,
          price: 899.99,
          originalPrice: 1099.99,
        },
        
        // Development Courses
        {
          id: 4,
          image: "/images/web-developments.webp",
          title: "Web Development",
          category: "Development",
          description: "Learn to build modern web applications.",
          instructor: "John Doe",
          rating: 4.8,
          students: 4120,
          price: 1499.99,
          originalPrice: 1799.99,
        },
        {
          id: 5,
          image: "/images/react-js-course.png",
          title: "React.js for Beginners to Advanced",
          category: "Development",
          description: "Master React.js from basics to advanced concepts.",
          instructor: "David Lee",
          rating: 4.8,
          students: 5621,
          price: 2094.99,
          originalPrice: 2149.99,
        },
        {
          id: 6,
          image: "/images/python-data.jpg",
          title: "Python for Data Science",
          category: "Development",
          description: "Use Python to analyze and visualize data.",
          instructor: "Andrew Thompson",
          rating: 4.9,
          students: 6120,
          price: 1109.99,
          originalPrice: 1769.99,
        },
        {
          id: 7,
          image: "/images/Data-science.jpg",
          title: "Data Science",
          category: "Development",
          description: "Analyze data and build models.",
          instructor: "Jane Smith",
          rating: 4.7,
          students: 3450,
          price: 1299.99,
          originalPrice: 1599.99,
        },
        
        // Marketing Courses
        {
          id: 8,
          image: "/images/digital-marketing.jpg",
          title: "Digital Marketing Masterclass",
          category: "Marketing",
          description: "Master digital marketing strategies.",
          instructor: "Jessica Brown",
          rating: 4.7,
          students: 2870,
          price: 1279.99,
          originalPrice: 1419.99,
        },
        
        // Business Courses
        {
          id: 9,
          image: "/images/Entrepreneurship.jpg",
          title: "Entrepreneurship 101",
          category: "Business",
          description: "Learn how to start and grow your own business.",
          instructor: "Robert Miller",
          rating: 4.8,
          students: 3750,
          price: 999.99,
          originalPrice: 759.99,
        },
        {
          id: 10,
          image: "/images/statistics-graph.jpg",
          title: "Business Statistics",
          category: "Business",
          description: "Understand and apply statistical methods for business.",
          instructor: "Olivia Green",
          rating: 4.6,
          students: 2100,
          price: 799.99,
          originalPrice: 999.99,
        },
        
        // Photography Courses
        {
          id: 11,
          image: "/images/photography-course.jpg",
          title: "Photography Fundamentals",
          category: "Photography",
          description: "Learn the basics of photography and composition.",
          instructor: "Mike Johnson",
          rating: 4.5,
          students: 1650,
          price: 699.99,
          originalPrice: 899.99,
        },
        
        // Music Courses
        {
          id: 12,
          image: "/images/music-production.jpg",
          title: "Music Production Basics",
          category: "Music",
          description: "Learn music production and audio engineering.",
          instructor: "Sarah Wilson",
          rating: 4.4,
          students: 1200,
          price: 599.99,
          originalPrice: 799.99,
        },
      ]);
      setLoading(false);
    }, 1000);
  }, [searchParams]);

  if (loading) return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading courses...</p>
        </div>
      </div>
      <Footer />
    </>
  );
  
  if (error) return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center text-red-500">{error}</div>
      </div>
      <Footer />
    </>
  );

  const filteredCourses = activeCategory === 'All' 
    ? courses 
    : courses.filter(course => course.category === activeCategory);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">All Courses</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover our comprehensive collection of courses designed to help you learn and grow.
            </p>
          </div>

          {/* Category Filter Buttons */}
          <div className="flex justify-center mb-10">
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-6 py-3 rounded-full text-sm font-medium transition-all duration-300 ${
                    activeCategory === category
                      ? 'bg-blue-600 text-white shadow-lg transform scale-105'
                      : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Results Count */}
          <div className="mb-6">
            <p className="text-gray-600">
              Showing {filteredCourses.length} course{filteredCourses.length !== 1 ? 's' : ''} 
              {activeCategory !== 'All' && ` in ${activeCategory}`}
            </p>
          </div>

          {/* Courses Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredCourses.map((course) => (
              <div key={course.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="relative h-48">
                  <img 
                    src={course.image} 
                    alt={course.title} 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.src = 'https://via.placeholder.com/400x300/f3f4f6/6b7280?text=Course+Image';
                    }}
                  />
                  <div className="absolute top-3 right-3 bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                    {course.category}
                  </div>
                </div>
                
                <div className="p-5">
                  <Link href={`/courses/${course.id}`}>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 hover:text-blue-600 transition-colors">
                      {course.title}
                    </h3>
                  </Link>
                  <p className="text-gray-600 text-sm mb-3">{course.description}</p>
                  <p className="text-gray-500 text-sm mb-3">By {course.instructor}</p>
                  
                  <div className="flex items-center mb-3">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(course.rating) ? 'fill-current' : 'text-gray-300'}`}
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-sm ml-2 text-gray-600">
                      {course.rating} ({course.students} students)
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold text-gray-900">₹{course.price}</span>
                      <span className="text-sm text-gray-500 line-through ml-2">₹{course.originalPrice}</span>
                    </div>
                    <Link 
                      href={`/courses/${course.id}`} 
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                    >
                      View Course
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No courses found in this category.</p>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default CoursesPage; 