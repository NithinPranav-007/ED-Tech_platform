'use client';
import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '../../../contexts/AuthContext';
import Header from '../../../components/common/Header';
import Footer from '../../../components/common/Footer';

const mockCourses = [
  // Design Courses
  {
    id: 1,
    image: "/images/advanced-ui-ux.avif",
    title: "Advanced UI/UX Design Principles",
    description: "Master advanced user interface and experience design.",
    instructor: "Emma Wilson",
    duration: "8 weeks",
    category: "Design",
    rating: 4.9,
    students: 3245,
    price: 1089.99,
    originalPrice: 1129.99,
    syllabus: [
      "Advanced Design Principles",
      "User Research & Testing",
      "Prototyping & Wireframing",
      "Design Systems & Components"
    ]
  },
  {
    id: 2,
    image: "/images/GRAPHIC-DESIGN.jpg",
    title: "Graphic Design Fundamentals",
    description: "Create stunning visuals and graphics.",
    instructor: "Sophia Martinez",
    duration: "7 weeks",
    category: "Design",
    rating: 4.7,
    students: 2560,
    price: 3274.99,
    originalPrice: 3709.99,
    syllabus: [
      "Design Principles",
      "Photoshop & Illustrator",
      "Branding & Identity",
      "Portfolio Project"
    ]
  },
  {
    id: 3,
    image: "/images/ui-ux.jpg",
    title: "UI/UX Fundamentals",
    description: "Learn the basics of UI and UX design.",
    instructor: "Chris White",
    duration: "4 weeks",
    category: "Design",
    rating: 4.6,
    students: 1890,
    price: 899.99,
    originalPrice: 1099.99,
    syllabus: [
      "UI Basics",
      "UX Principles",
      "Design Tools",
      "Mini Project"
    ]
  },
  
  // Development Courses
  {
    id: 4,
    image: "/images/web-developments.webp",
    title: "Web Development",
    description: "Learn to build modern web applications.",
    instructor: "John Doe",
    duration: "8 weeks",
    category: "Development",
    rating: 4.8,
    students: 4120,
    price: 1499.99,
    originalPrice: 1799.99,
    syllabus: [
      "HTML, CSS, JavaScript",
      "React & Next.js",
      "Backend Basics",
      "Deployment"
    ]
  },
  {
    id: 5,
    image: "/images/react-js-course.png",
    title: "React.js for Beginners to Advanced",
    description: "Master React.js from basics to advanced concepts.",
    instructor: "David Lee",
    duration: "10 weeks",
    category: "Development",
    rating: 4.8,
    students: 5621,
    price: 2094.99,
    originalPrice: 2149.99,
    syllabus: [
      "React Fundamentals",
      "Hooks & State Management",
      "Advanced Patterns",
      "Real-world Projects"
    ]
  },
  {
    id: 6,
    image: "/images/python-data.jpg",
    title: "Python for Data Science",
    description: "Use Python to analyze and visualize data.",
    instructor: "Andrew Thompson",
    duration: "6 weeks",
    category: "Development",
    rating: 4.9,
    students: 6120,
    price: 1109.99,
    originalPrice: 1769.99,
    syllabus: [
      "Python Basics",
      "Pandas & Numpy",
      "Data Visualization",
      "Mini Project"
    ]
  },
  {
    id: 7,
    image: "/images/Data-science.jpg",
    title: "Data Science",
    description: "Analyze data and build models.",
    instructor: "Jane Smith",
    duration: "10 weeks",
    category: "Development",
    rating: 4.7,
    students: 3450,
    price: 1299.99,
    originalPrice: 1599.99,
    syllabus: [
      "Python Basics",
      "Data Analysis",
      "Machine Learning",
      "Visualization"
    ]
  },
  
  // Marketing Courses
  {
    id: 8,
    image: "/images/digital-marketing.jpg",
    title: "Digital Marketing Masterclass",
    description: "Master digital marketing strategies.",
    instructor: "Jessica Brown",
    duration: "6 weeks",
    category: "Marketing",
    rating: 4.7,
    students: 2870,
    price: 1279.99,
    originalPrice: 1419.99,
    syllabus: [
      "SEO & SEM",
      "Content Marketing",
      "Social Media",
      "Analytics"
    ]
  },
  
  // Business Courses
  {
    id: 9,
    image: "/images/Entrepreneurship.jpg",
    title: "Entrepreneurship 101",
    description: "Learn how to start and grow your own business.",
    instructor: "Robert Miller",
    duration: "9 weeks",
    category: "Business",
    rating: 4.8,
    students: 3750,
    price: 999.99,
    originalPrice: 759.99,
    syllabus: [
      "Business Models",
      "Funding & Finance",
      "Marketing",
      "Scaling Up"
    ]
  },
  {
    id: 10,
    image: "/images/statistics-graph.jpg",
    title: "Business Statistics",
    description: "Understand and apply statistical methods for business.",
    instructor: "Olivia Green",
    duration: "5 weeks",
    category: "Business",
    rating: 4.6,
    students: 2100,
    price: 799.99,
    originalPrice: 999.99,
    syllabus: [
      "Descriptive Stats",
      "Probability",
      "Inferential Stats",
      "Real-world Applications"
    ]
  },
  
  // Photography Courses
  {
    id: 11,
    image: "/images/photography-course.jpg",
    title: "Photography Fundamentals",
    description: "Learn the basics of photography and composition.",
    instructor: "Mike Johnson",
    duration: "6 weeks",
    category: "Photography",
    rating: 4.5,
    students: 1650,
    price: 699.99,
    originalPrice: 899.99,
    syllabus: [
      "Camera Basics",
      "Composition & Lighting",
      "Post-processing",
      "Portfolio Building"
    ]
  },
  
  // Music Courses
  {
    id: 12,
    image: "/images/music-production.jpg",
    title: "Music Production Basics",
    description: "Learn music production and audio engineering.",
    instructor: "Sarah Wilson",
    duration: "8 weeks",
    category: "Music",
    rating: 4.4,
    students: 1200,
    price: 599.99,
    originalPrice: 799.99,
    syllabus: [
      "DAW Basics",
      "Sound Design",
      "Mixing & Mastering",
      "Project Completion"
    ]
  }
];

export default function CourseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { currentUser } = useAuth();
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [showVideo, setShowVideo] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  
  const courseId = parseInt(params.id, 10);
  const course = mockCourses.find(c => c.id === courseId);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  // Simulate progress tracking
  useEffect(() => {
    if (currentUser) {
      setProgress(Math.floor(Math.random() * 30) + 10); // Random progress 10-40%
    }
  }, [currentUser]);

  const handleEnroll = async () => {
    if (!currentUser) {
      setShowLoginModal(true);
      return;
    }

    setIsEnrolling(true);
    
    // Simulate enrollment process
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Here you would typically save enrollment to Firebase
      // For now, we'll just redirect to My Learning page
      router.push('/my-learning');
    } catch (error) {
      console.error('Enrollment failed:', error);
      alert('Enrollment failed. Please try again.');
    } finally {
      setIsEnrolling(false);
    }
  };

  const handleWishlist = () => {
    if (!currentUser) {
      setShowLoginModal(true);
      return;
    }
    setIsWishlisted(!isWishlisted);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: course.title,
        text: course.description,
        url: window.location.href,
      });
    } else {
      setShowShareModal(true);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Link copied to clipboard!');
    setShowShareModal(false);
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <svg
        key={i}
        className={`w-4 h-4 ${i < Math.floor(rating) ? 'text-yellow-400' : 'text-gray-300'}`}
        fill="currentColor"
        viewBox="0 0 20 20"
      >
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
    ));
  };

  if (isLoading) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <h2 className="text-xl font-semibold text-gray-700">Loading course...</h2>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (!course) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center text-red-500">
            <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold mb-4">Course Not Found</h2>
            <p className="mb-4 text-gray-600">The course you're looking for doesn't exist.</p>
            <Link href="/courses" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Browse All Courses
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Enhanced Breadcrumb */}
          <div className="mb-8">
            <nav className="flex items-center space-x-2 text-sm">
              <Link href="/" className="text-gray-500 hover:text-blue-600 transition-colors">Home</Link>
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              <Link href="/courses" className="text-gray-500 hover:text-blue-600 transition-colors">Courses</Link>
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              <span className="text-gray-900 font-medium">{course.title}</span>
            </nav>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Enhanced Course Banner */}
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                <div className="relative h-80 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700">
                  <div className="absolute inset-0 bg-black bg-opacity-20"></div>
                  <img 
                    src={course.image} 
                    alt={course.title} 
                    className="w-full h-full object-cover opacity-30"
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center text-white">
                      <div className="mb-4">
                        <span className="bg-white bg-opacity-20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium border border-white border-opacity-30">
                          {course.category}
                        </span>
                      </div>
                      <h1 className="text-5xl font-bold mb-4 drop-shadow-lg">{course.title}</h1>
                      <p className="text-xl text-blue-100 max-w-2xl mx-auto">{course.description}</p>
                    </div>
                  </div>
                  
                  {/* Floating Action Buttons */}
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <button
                      onClick={handleWishlist}
                      className={`p-3 rounded-full backdrop-blur-sm transition-all duration-300 ${
                        isWishlisted 
                          ? 'bg-red-500 text-white shadow-lg scale-110' 
                          : 'bg-white bg-opacity-20 text-white hover:bg-opacity-30'
                      }`}
                    >
                      <svg className="w-5 h-5" fill={isWishlisted ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </button>
                    <button
                      onClick={handleShare}
                      className="p-3 rounded-full bg-white bg-opacity-20 text-white hover:bg-opacity-30 backdrop-blur-sm transition-all duration-300"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
                      </svg>
                    </button>
                  </div>
                </div>

                <div className="p-8">
                  {/* Enhanced Course Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                    <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                      <div className="flex items-center justify-center mb-2">
                        {renderStars(course.rating)}
                      </div>
                      <div className="text-2xl font-bold text-blue-600">{course.rating}</div>
                      <div className="text-sm text-gray-600">Rating</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
                      <div className="text-3xl mb-2">👥</div>
                      <div className="text-2xl font-bold text-green-600">{course.students.toLocaleString()}</div>
                      <div className="text-sm text-gray-600">Students</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
                      <div className="text-3xl mb-2">⏱️</div>
                      <div className="text-2xl font-bold text-purple-600">{course.duration}</div>
                      <div className="text-sm text-gray-600">Duration</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl">
                      <div className="text-3xl mb-2">📚</div>
                      <div className="text-2xl font-bold text-orange-600">{course.syllabus.length}</div>
                      <div className="text-sm text-gray-600">Modules</div>
                    </div>
                  </div>

                  {/* Progress Bar (if user is enrolled) */}
                  {currentUser && progress > 0 && (
                    <div className="mb-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">Your Progress</h3>
                        <span className="text-sm font-medium text-blue-600">{progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-1000 ease-out"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600 mt-2">Continue where you left off</p>
                    </div>
                  )}

                  {/* Tab Navigation */}
                  <div className="border-b border-gray-200 mb-8">
                    <nav className="flex space-x-8">
                      {['overview', 'curriculum', 'reviews', 'instructor'].map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setActiveTab(tab)}
                          className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                            activeTab === tab
                              ? 'border-blue-500 text-blue-600'
                              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                          }`}
                        >
                          {tab.charAt(0).toUpperCase() + tab.slice(1)}
                        </button>
                      ))}
                    </nav>
                  </div>

                  {/* Tab Content */}
                  <div className="min-h-96">
                    {activeTab === 'overview' && (
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-6">Course Overview</h3>
                        <div className="prose prose-lg max-w-none">
                          <p className="text-gray-700 leading-relaxed mb-6">
                            {course.description} This comprehensive course is designed to take you from beginner to advanced level, 
                            providing hands-on experience with real-world projects and industry best practices.
                          </p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                            <div className="bg-gray-50 p-6 rounded-xl">
                              <h4 className="font-semibold text-gray-900 mb-3">What you'll learn</h4>
                              <div className="space-y-3">
                                {course.syllabus.map((item, idx) => (
                                  <div key={idx} className="flex items-start">
                                    <svg className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                    </svg>
                                    <span className="text-gray-700">{item}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                            
                            <div className="bg-gray-50 p-6 rounded-xl">
                              <h4 className="font-semibold text-gray-900 mb-3">Course Features</h4>
                              <div className="space-y-3">
                                <div className="flex items-center">
                                  <svg className="w-5 h-5 text-blue-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                  <span className="text-gray-700">HD Video Lectures</span>
                                </div>
                                <div className="flex items-center">
                                  <svg className="w-5 h-5 text-blue-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                  <span className="text-gray-700">Downloadable Resources</span>
                                </div>
                                <div className="flex items-center">
                                  <svg className="w-5 h-5 text-blue-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                  <span className="text-gray-700">Certificate of Completion</span>
                                </div>
                                <div className="flex items-center">
                                  <svg className="w-5 h-5 text-blue-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                  </svg>
                                  <span className="text-gray-700">Lifetime Access</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeTab === 'curriculum' && (
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-6">Course Curriculum</h3>
                        <div className="space-y-4">
                          {course.syllabus.map((item, idx) => (
                            <div key={idx} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                                    <span className="text-blue-600 font-semibold text-sm">{idx + 1}</span>
                                  </div>
                                  <div>
                                    <h4 className="font-semibold text-gray-900">{item}</h4>
                                    <p className="text-sm text-gray-600">Module {idx + 1}</p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <span className="text-sm text-gray-500">45 min</span>
                                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                  </svg>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeTab === 'reviews' && (
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-6">Student Reviews</h3>
                        <div className="space-y-6">
                          {[1, 2, 3].map((review) => (
                            <div key={review} className="bg-white border border-gray-200 rounded-lg p-6">
                              <div className="flex items-center mb-4">
                                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mr-4">
                                  <span className="text-white font-semibold">U{review}</span>
                                </div>
                                <div>
                                  <h4 className="font-semibold text-gray-900">User {review}</h4>
                                  <div className="flex items-center">
                                    {renderStars(4.5)}
                                    <span className="text-sm text-gray-600 ml-2">2 days ago</span>
                                  </div>
                                </div>
                              </div>
                              <p className="text-gray-700">
                                "Amazing course! The instructor explains everything clearly and the hands-on projects really help solidify the concepts. Highly recommended!"
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeTab === 'instructor' && (
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-6">About the Instructor</h3>
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8">
                          <div className="flex items-start space-x-6">
                            <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                              <span className="text-white text-2xl font-bold">
                                {course.instructor.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div className="flex-1">
                              <h3 className="text-2xl font-bold text-gray-900 mb-2">{course.instructor}</h3>
                              <p className="text-blue-600 font-medium mb-4">Expert Instructor & Industry Professional</p>
                              <p className="text-gray-700 leading-relaxed mb-4">
                                {course.instructor} is a seasoned professional with over 10 years of experience in the field. 
                                They have helped thousands of students master the skills needed to succeed in their careers.
                              </p>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="text-center p-3 bg-white rounded-lg">
                                  <div className="text-2xl font-bold text-blue-600">10+</div>
                                  <div className="text-sm text-gray-600">Years Experience</div>
                                </div>
                                <div className="text-center p-3 bg-white rounded-lg">
                                  <div className="text-2xl font-bold text-green-600">50K+</div>
                                  <div className="text-sm text-gray-600">Students Taught</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Enhanced Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-8 space-y-6">
                {/* Pricing Card */}
                <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-gray-900 mb-2">₹{course.price}</div>
                    <div className="text-xl text-gray-500 line-through">₹{course.originalPrice}</div>
                    <div className="inline-block bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full mt-2">
                      {Math.round(((course.originalPrice - course.price) / course.originalPrice) * 100)}% OFF
                    </div>
                  </div>

                  <button
                    onClick={handleEnroll}
                    disabled={isEnrolling}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 disabled:transform-none mb-4 shadow-lg"
                  >
                    {isEnrolling ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Enrolling...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Enroll Now
                      </div>
                    )}
                  </button>

                  <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      Full lifetime access
                    </div>
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      Access on mobile and TV
                    </div>
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      Certificate of completion
                    </div>
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-green-500 mr-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      30-Day money-back guarantee
                    </div>
                  </div>
                </div>

                {/* Course Preview */}
                <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                  <div className="relative">
                    <img 
                      src={course.image} 
                      alt="Course Preview" 
                      className="w-full h-48 object-cover"
                      onError={(e) => {
                        e.target.style.display = 'none';
                      }}
                    />
                    <button
                      onClick={() => setShowVideo(true)}
                      className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 hover:bg-opacity-70 transition-all duration-300"
                    >
                      <div className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                        <svg className="w-8 h-8 text-gray-900 ml-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z"/>
                        </svg>
                      </div>
                    </button>
                  </div>
                  <div className="p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Course Preview</h4>
                    <p className="text-sm text-gray-600">Watch a sample lesson to see what you'll learn</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl transform transition-all">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Login Required</h3>
              <p className="text-gray-600">
                Please log in to enroll in this course and access all features.
              </p>
            </div>
            <div className="space-y-4">
              <Link
                href="/login"
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 text-center block"
              >
                Login to Continue
              </Link>
              <button
                onClick={() => setShowLoginModal(false)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Share Course</h3>
              <p className="text-gray-600">Share this amazing course with friends!</p>
            </div>
            <div className="space-y-4">
              <div className="flex items-center p-3 border border-gray-200 rounded-lg">
                <input
                  type="text"
                  value={window.location.href}
                  readOnly
                  className="flex-1 bg-gray-50 px-3 py-2 rounded border-none focus:outline-none"
                />
                <button
                  onClick={() => copyToClipboard(window.location.href)}
                  className="ml-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Copy
                </button>
              </div>
              <div className="flex space-x-4">
                <button
                  onClick={() => copyToClipboard(`Check out this course: ${course.title} - ${window.location.href}`)}
                  className="flex-1 px-4 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
                >
                  Share on WhatsApp
                </button>
                <button
                  onClick={() => copyToClipboard(`I found this amazing course: ${course.title} - ${window.location.href}`)}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                >
                  Share on Twitter
                </button>
              </div>
              <button
                onClick={() => setShowShareModal(false)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Video Preview Modal */}
      {showVideo && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl overflow-hidden max-w-4xl w-full shadow-2xl">
            <div className="relative">
              <div className="aspect-video bg-gray-900 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z"/>
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Course Preview</h3>
                  <p className="text-gray-300">Sample lesson from {course.title}</p>
                </div>
              </div>
              <button
                onClick={() => setShowVideo(false)}
                className="absolute top-4 right-4 w-10 h-10 bg-black bg-opacity-50 text-white rounded-full flex items-center justify-center hover:bg-opacity-75 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-6">
              <h4 className="text-xl font-bold text-gray-900 mb-2">What you'll see in this course</h4>
              <p className="text-gray-600 mb-4">
                Get a taste of the high-quality content and teaching style you can expect throughout the course.
              </p>
              <button
                onClick={() => setShowVideo(false)}
                className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-xl hover:bg-blue-700 transition-colors"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Notification */}
      {isWishlisted && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-xl shadow-lg z-50 transform transition-all duration-300 animate-bounce">
          <div className="flex items-center">
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Added to wishlist!
          </div>
        </div>
      )}
      <Footer />
    </>
  );
} 