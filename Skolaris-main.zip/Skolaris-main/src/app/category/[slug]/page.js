"use client";
import { useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';

const CategoryPage = () => {
  const router = useRouter();
  const params = useParams();
  const categorySlug = params.slug;

  useEffect(() => {
    // Convert slug to proper category name
    const categoryMap = {
      'design': 'Design',
      'development': 'Development',
      'marketing': 'Marketing',
      'business': 'Business',
      'photography': 'Photography',
      'music': 'Music'
    };

    const categoryName = categoryMap[categorySlug] || categorySlug;
    router.replace(`/courses?category=${categoryName}`);
  }, [categorySlug, router]);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Redirecting to courses...</p>
      </div>
    </div>
  );
};

export default CategoryPage; 